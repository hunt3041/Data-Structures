CSX MACHINE USED: csx3.cs.okstate.edu

How to run program: 

1. Download the input file from canvas into the same directory as you plan to put the program

2. Use putty to open csx3.cs.okstate.edu machine

3. Download all .java files and the mypackage directory into a the same directory as the .txt files from canvas

4. Run command: javac *.java to compile all files

5. Run command: java Main <inputFileName> 
    - Where inputFileName is the .txt file that you want to run

6. The output should be displayed. 